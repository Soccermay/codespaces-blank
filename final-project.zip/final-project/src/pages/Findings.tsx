import { IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonInput, IonLabel, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import { arrowBack } from 'ionicons/icons';
import './Tab2.css';


const Login: React.FC = () => {
  return (
    <IonPage>
      <IonHeader class="ion-no-border">
        <IonToolbar color="danger">
          <IonButtons slot="start">
          <IonButton color="success">
            <IonIcon icon={arrowBack}></IonIcon>
        </IonButton>
        </IonButtons>
        <IonButtons slot="end">
          <IonButton routerLink='signup'>Sign-up</IonButton>
        </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding" color={'medium'}>
        <div id="header">
        <h1>Welcome to the clothing Site</h1>
          <h1>Login</h1>
          <img src="assets/Icon.png"></img>
        </div>
        
        <form id="#form">
          <IonLabel>UserName:</IonLabel>           
          <IonInput color={'warning'} placeholder="Enter Text" ></IonInput>
          <IonLabel>Password:</IonLabel>
          <IonInput type="password" color={'warning'} placeholder="Enter Text" maxlength={15}></IonInput>
        <IonButton routerLink="/Wallet" expand="block" shape="round" color={'success'}>Login</IonButton>
        </form>
      </IonContent>
    </IonPage>
  );
};
export default Login;
