import { IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonInput, IonLabel, IonPage, IonTitle, IonToolbar } from '@ionic/react'
import ExploreContainer from '../components/ExploreContainer';
import { arrowBack } from 'ionicons/icons';
import './signup.css';

const signup: React.FC = () => {
  return (
  <IonPage>
      <IonHeader class="ion-no-border">
        <IonToolbar color="secondary">
          <IonButtons slot="start">
          <IonButton color="success">
            <IonIcon icon={arrowBack}></IonIcon>
        </IonButton>
        </IonButtons>
        <IonButtons slot="end">
          <IonButton routerLink="/Findings">Log in</IonButton>
        </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding" color={'medium'}>
        <div id="header">
          <h1>Create your <br /> Account</h1>
        </div>
        
        <form id="#form">         
          <IonInput color={'primary'} placeholder="Your Name"></IonInput>
          <IonInput color={'primary'} placeholder="Email Address"></IonInput>
          <IonInput type="password" color={'primary'} placeholder="Password" maxlength={15}></IonInput>
        <IonButton expand="block" shape="round" color={'primary'} routerLink="/Wallet">Join us!</IonButton>
        </form>

        <p>By clicking 'Join us' you <br />agree to our terms and conditions</p>
      </IonContent>
    </IonPage>
  )
}
export default signup;