import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab3.css';

const Tool: React.FC = () => {
  
  return ( 
      <IonPage>
      <IonHeader>
        <IonToolbar color="light">
          <IonTitle>Tool</IonTitle>
        </IonToolbar>
       </IonHeader>
       <IonContent className="ion-padding"></IonContent>
    </IonPage>
  );
};

export default Tool;
