import { IonButton, IonButtons, IonCard, IonCol, IonContent, IonFooter, IonGrid, IonHeader, IonIcon, IonItem, IonLabel, IonList, IonListHeader, IonPage, IonRow, IonText, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import { arrowBack, personCircleOutline } from 'ionicons/icons';
import './Tab1.css';

const Wallet: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="danger" class='ion-no-border'>
          <IonButtons slot="start">
              <IonButton expand="block" color="success">
                <IonIcon icon={arrowBack}></IonIcon>
              </IonButton>
          </IonButtons>
          <IonTitle>Checkout</IonTitle>
          <IonButtons slot="end">
              <IonButton expand="block">Mr.John Smith
                <IonIcon icon={personCircleOutline} size="large"></IonIcon>
              </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent>
        <IonGrid >
          <IonRow>
            <IonCol>
              <IonCard>

                <IonList>
                  <IonItem lines="full" color="dark">
                  CLASSIC POLO SHIRT 
                  </IonItem>
                  <IonItem lines="full">
                    <IonRow align-items-center>
                      <IonCol size="5" no-padding>
                        <img src="assets/icon/Polo.jpg" width={500}/>
                      </IonCol>
                      <IonCol no-padding size="7">
                        <IonRow align-items-center>
                          <IonCol size="6">Price    :</IonCol>
                          <IonCol size="6">$ 100</IonCol>
                        </IonRow>
                      <IonRow align-items-center>
                        <IonCol size="6">Quantity -</IonCol>
                        <IonCol size="8">
                            <IonButton size="small" shape="round" fill="outline">
                              -
                            </IonButton>
                            <IonText>
                              1
                            </IonText>
                            <IonButton size="small" shape="round" fill="outline">
                              +
                            </IonButton>
                        </IonCol>
                       </IonRow>
                       <IonRow align-items-center>
                        <IonCol size="5">
                          <b>Sub Total :</b>
                        </IonCol>
                        <IonCol size="7">
                          <b>100</b>
                        </IonCol>
                       </IonRow>
                      </IonCol>
                    </IonRow>
                  </IonItem>
                  <IonItem color="light">
                    <IonButton color="success">
                      View
                    </IonButton>
                    <IonButton fill="clear" color="tertiary">
                      Remove
                    </IonButton>
                  </IonItem>      
                </IonList>

          
                <IonList>
                  <IonItem lines="full" color="dark">
                    Classic Fit Shirt
                  </IonItem>
                  <IonItem lines="full">
                    <IonRow align-items-center>
                      <IonCol size="5" no-padding>
                        <img src="assets/icon/Classic.jpg" width={320}/>
                      </IonCol>
                      <IonCol no-padding size="7">
                        <IonRow align-items-center>
                          <IonCol size="6">Price    :</IonCol>
                          <IonCol size="6">$ 150</IonCol>
                        </IonRow>
                      <IonRow align-items-center>
                        <IonCol size="6">Quantity -</IonCol>
                        <IonCol size="8">
                            <IonButton size="small" shape="round" fill="outline">
                              -
                            </IonButton>
                            <IonText>
                              1
                            </IonText>
                            <IonButton size="small" shape="round" fill="outline">
                              +
                            </IonButton>
                        </IonCol>
                       </IonRow>
                       <IonRow align-items-center>
                        <IonCol size="5">
                          <b>Sub Total :</b>
                        </IonCol>
                        <IonCol size="7">
                          <b>150</b>
                        </IonCol>
                       </IonRow>
                      </IonCol>
                    </IonRow>
                  </IonItem>
                  <IonItem color="light">
                    <IonButton color="success">
                      View
                    </IonButton>
                    <IonButton fill="clear" color="tertiary">
                      Remove
                    </IonButton>  
                  </IonItem>      
                </IonList>

                <IonList>
                  <IonItem lines="full" color="dark">
                  BUTTONED UP FLANNEL 
                  </IonItem>
                  <IonItem lines="full">
                    <IonRow align-items-center>
                      <IonCol size="5" no-padding>
                        <img src="assets/icon/Flannel.jpg" width={320}/>
                      </IonCol>
                      <IonCol no-padding size="7">
                        <IonRow align-items-center>
                          <IonCol size="6">Price    :</IonCol>
                          <IonCol size="6">$ 220</IonCol>
                        </IonRow>
                      <IonRow align-items-center>
                        <IonCol size="6">Quantity -</IonCol>
                        <IonCol size="8">
                            <IonButton size="small" shape="round" fill="outline">
                              -
                            </IonButton>
                            <IonText>
                              1
                            </IonText>
                            <IonButton size="small" shape="round" fill="outline">
                              +
                            </IonButton>
                        </IonCol>
                       </IonRow>
                       <IonRow align-items-center>
                        <IonCol size="5">
                          <b>Sub Total :</b>
                        </IonCol>
                        <IonCol size="7">
                          <b>220</b>
                        </IonCol>
                       </IonRow>
                      </IonCol>
                    </IonRow>
                  </IonItem>
                  <IonItem color="light">
                    <IonButton color="success">
                      View
                    </IonButton>
                    <IonButton fill="clear" color="tertiary">
                      Remove
                    </IonButton>  
                  </IonItem>      
                </IonList>

                
                <IonList>
                  <IonItem lines="full" color="dark">
                  Designer Jeans
                  </IonItem>
                  <IonItem lines="full">
                    <IonRow align-items-center>
                      <IonCol size="5" no-padding>
                        <img src="assets/icon/Jeans.jpg" width={320}/>
                      </IonCol>
                      <IonCol no-padding size="7">
                        <IonRow align-items-center>
                          <IonCol size="6">Price    :</IonCol>
                          <IonCol size="6">$ 180</IonCol>
                        </IonRow>
                      <IonRow align-items-center>
                        <IonCol size="6">Quantity -</IonCol>
                        <IonCol size="8">
                            <IonButton size="small" shape="round" fill="outline">
                              -
                            </IonButton>
                            <IonText>
                              1
                            </IonText>
                            <IonButton size="small" shape="round" fill="outline">
                              +
                            </IonButton>
                        </IonCol>
                       </IonRow>
                       <IonRow align-items-center>
                        <IonCol size="5">
                          <b>Sub Total :</b>
                        </IonCol>
                        <IonCol size="7">
                          <b>180</b>
                        </IonCol>
                       </IonRow>
                      </IonCol>
                    </IonRow>
                  </IonItem>
                  <IonItem color="light">
                    <IonButton color="success">
                      View
                    </IonButton>
                    <IonButton fill="clear" color="tertiary">
                      Remove
                    </IonButton>  
                  </IonItem>      
                </IonList>

                
                <IonList>
                  <IonItem lines="full" color="dark">
                  Nike Slides 
                  </IonItem>
                  <IonItem lines="full">
                    <IonRow align-items-center>
                      <IonCol size="5" no-padding>
                        <img src="assets/icon/Slides.jpg" width={320}/>
                      </IonCol>
                      <IonCol no-padding size="7">
                        <IonRow align-items-center>
                          <IonCol size="6">Price    :</IonCol>
                          <IonCol size="6">$ 60</IonCol>
                        </IonRow>
                      <IonRow align-items-center>
                        <IonCol size="6">Quantity -</IonCol>
                        <IonCol size="8">
                            <IonButton size="small" shape="round" fill="outline">
                              -
                            </IonButton>
                            <IonText>
                              1
                            </IonText>
                            <IonButton size="small" shape="round" fill="outline">
                              +
                            </IonButton>
                        </IonCol>
                       </IonRow>
                       <IonRow align-items-center>
                        <IonCol size="5">
                          <b>Sub Total :</b>
                        </IonCol>
                        <IonCol size="7">
                          <b>60</b>
                        </IonCol>
                       </IonRow>
                      </IonCol>
                    </IonRow>
                  </IonItem>
                  <IonItem color="light">
                    <IonButton color="success">
                      View
                    </IonButton>
                    <IonButton fill="clear" color="tertiary">
                      Remove
                    </IonButton>  
                  </IonItem>      
                </IonList>


                <IonList>
                  <IonItem lines="full" color="dark">
                  Jordan 1s OG Pollen
                  </IonItem>
                  <IonItem lines="full">
                    <IonRow align-items-center>
                      <IonCol size="5" no-padding>
                        <img src="assets/icon/Jordan 1s.jpg" width={420}/>
                      </IonCol>
                      <IonCol no-padding size="7">
                        <IonRow align-items-center>
                          <IonCol size="6">Price    :</IonCol>
                          <IonCol size="6">$ 160</IonCol>
                        </IonRow>
                      <IonRow align-items-center>
                        <IonCol size="6">Quantity -</IonCol>
                        <IonCol size="8">
                            <IonButton size="small" shape="round" fill="outline">
                              -
                            </IonButton>
                            <IonText>
                              1
                            </IonText>
                            <IonButton size="small" shape="round" fill="outline">
                              +
                            </IonButton>
                        </IonCol>
                       </IonRow>
                       <IonRow align-items-center>
                        <IonCol size="5">
                          <b>Sub Total :</b>
                        </IonCol>
                        <IonCol size="7">
                          <b>160</b>
                        </IonCol>
                       </IonRow>
                      </IonCol>
                    </IonRow>
                  </IonItem>
                  <IonItem color="light">
                    <IonButton color="success">
                      View
                    </IonButton>
                    <IonButton fill="clear" color="tertiary">
                      Remove
                    </IonButton>  
                  </IonItem>      
                </IonList>

              </IonCard>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>

      <IonFooter>
        <IonRow>
          <IonCol size="7">
            <IonText>
              <h4>Total : $160.52</h4>
            </IonText>
          </IonCol>
          <IonCol size="5">
            <IonButton color="light">Proceed</IonButton>
          </IonCol>
        </IonRow>
      </IonFooter>
    </IonPage>
  );
};

export default Wallet;
